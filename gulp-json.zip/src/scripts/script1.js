function clickButton(){
    console.log("Button is clicked");
}