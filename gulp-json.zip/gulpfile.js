var gulp = require("gulp");

var gulp_css = require("./gulp-css.js");
var gulp_image = require("./gulp-image.js");
var gulp_js = require("./gulp-js.js");
var gulp_json = require("./gulp-json.js");
var gulp_html=require("./gulp-html.js");
var concat = require('gulp-concat');


gulp.task(
  "final",
  gulp.parallel(
    //gulp_css.cssTasks,
    //gulp_image.imageTasks,
    //gulp_js.jsTasks
    //gulp_json.jsonTasks
    gulp_html.htmlTasks
  )
);

gulp.task('con',function html(done){
  return gulp.src(['src/components/header/header.html','src/components/body/body.html','src/components/footer/footer.html'])
    .pipe(concat('all.html'))
    .pipe(gulp.dest('./temp/'))
    done();
});

gulp.task("default", gulp.series("final"));
