(function () {
    $('head').append('<style><%= head %></style>');

    $('.background-egi').replaceWith('<%= body %>');

    <%= javascript %>

}).call(this);